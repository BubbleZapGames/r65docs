"""
FixedStack ABI mandatory parameter promotion.

Pre-pass that runs before codegen when --abi FixedStack is active. Promotes ALL
remaining stack parameters to hardware registers or scratch registers. Emits a
compile error if any parameter cannot be placed.

This replaces scratch_params.py for FixedStack mode.
"""

from typing import Dict, Set, List, Tuple
from r65.compiler.mir.nodes import (
    MIRProgram, MIRFunction, Call, ArgumentMechanism,
    Move, VirtualRegister, HardwareRegister, TraitDispatch,
)
from r65.compiler.codegen.register_alloc import ScratchRegisterPool
from r65.compiler.codegen.type_utils import get_type_size
from r65.compiler.errors import CodegenError
from r65.compiler.analysis.param_utils import find_address_taken_functions, find_composite_scratch


def promote_all_stack_params(mir_program: MIRProgram, scratch_pool: ScratchRegisterPool):
    """
    Promote ALL stack parameters to hw registers or scratch registers.

    Compile error if any parameter cannot be placed. This is mandatory for
    FixedStack ABI where no stack-passed parameters are allowed.

    Also sets max_outgoing_arg_bytes = 0 for all functions (FixedStack has no
    outgoing arg area).

    Args:
        mir_program: MIR program to analyze (mutated in place)
        scratch_pool: Pool of available scratch registers
    """
    # Step 0: Reject recursive functions — DP scratch params are non-reentrant
    _reject_recursive_functions(mir_program)

    # Step 1: Find functions whose address is taken
    address_taken = find_address_taken_functions(mir_program)

    # Step 2: For each function, promote all stack params
    # Build promotions: function_name -> {param_idx: ('hw', reg_name) | ('scratch', addr)}
    all_promotions: Dict[str, Dict[int, Tuple[str, object]]] = {}

    for func in mir_program.functions:
        if not func.stack_param_offsets:
            continue

        # Address-taken functions in FixedStack mode: error if they have unbound stack params
        if func.name in address_taken:
            raise CodegenError(
                f"FixedStack ABI: function '{func.name}' has its address taken but has "
                f"stack parameters. Add explicit register bindings (@ A, @ X, etc.) to all parameters.",
                source_loc=func.source_loc,
            )

        promotions = _promote_function_params(func, scratch_pool)
        if promotions:
            all_promotions[func.name] = promotions

    if not all_promotions:
        # No stack params in the whole program — nothing to do
        for func in mir_program.functions:
            func.max_outgoing_arg_bytes = 0
        return

    # Step 3: Apply promotions to callee functions
    total_hw = 0
    total_scratch = 0
    for func in mir_program.functions:
        if func.name not in all_promotions:
            continue
        func_promos = all_promotions[func.name]
        for param_idx, (kind, loc) in func_promos.items():
            if kind == 'hw':
                func.hw_param_regs[param_idx] = loc
                total_hw += 1
            elif kind == 'scratch':
                func.scratch_param_addrs[param_idx] = loc
                total_scratch += 1

        # Add Move instructions from hw reg to vreg for hw-promoted params
        _inject_hw_param_moves(func)

        # Remove promoted params from stack_param_offsets
        for param_idx in func_promos:
            if param_idx in func.stack_param_offsets:
                del func.stack_param_offsets[param_idx]

        # Clear far pointer stack param flag if all far ptrs promoted off stack
        if func.far_ptr_param_indices:
            remaining_far = func.far_ptr_param_indices - set(func_promos.keys())
            if not remaining_far:
                func.has_far_ptr_stack_params = False
                func.far_ptr_param_indices.clear()

    # Step 4: Collect global set of all scratch param addresses.
    # Any function's locals must avoid these addresses because a caller's
    # scratch params persist across calls while the callee runs.
    # For multi-byte params, include ALL bytes in the range (e.g. u16 at $00 → {$00, $01}).
    global_scratch_param_addrs: Set[int] = set()
    for func in mir_program.functions:
        for param_idx, base_addr in func.scratch_param_addrs.items():
            param_size = get_type_size(func.parameters[param_idx].param_type)
            for offset in range(param_size):
                global_scratch_param_addrs.add(base_addr + offset)
    # Store on each function so function_gen.py can access it
    for func in mir_program.functions:
        func._global_scratch_param_addrs = global_scratch_param_addrs

    # Step 5: Update call sites
    for func in mir_program.functions:
        _update_call_sites(func, all_promotions)

    # Step 6: Zero out outgoing arg bytes for all functions
    for func in mir_program.functions:
        func.max_outgoing_arg_bytes = 0

    total = total_hw + total_scratch
    if total > 0:
        parts = []
        if total_hw > 0:
            parts.append(f"{total_hw} to hw regs")
        if total_scratch > 0:
            parts.append(f"{total_scratch} to scratch")
        print(f"FixedStack parameter promotion: {total} parameter(s) promoted ({', '.join(parts)})")


def _reject_recursive_functions(mir_program: MIRProgram):
    """Detect recursive functions and raise an error.

    FixedStack ABI promotes parameters to DP scratch registers which are
    global, not per-invocation. Recursive calls would overwrite the
    caller's scratch values, producing incorrect code.

    Detects both direct recursion (A calls A) and mutual recursion
    (A calls B, B calls A).
    """
    from r65.compiler.analysis.call_graph import CallGraphAnalyzer

    analyzer = CallGraphAnalyzer(mir_program)
    analyzer.analyze()
    cycles = analyzer.find_cycles()

    if not cycles:
        return

    # Report the first cycle found
    cycle = cycles[0]
    func_by_name = {f.name: f for f in mir_program.functions}
    func = func_by_name.get(cycle[0])
    source_loc = func.source_loc if func else None

    if len(cycle) == 1:
        raise CodegenError(
            f"FixedStack ABI does not support recursive functions. "
            f"Function '{cycle[0]}' calls itself. "
            f"Use '--abi Default' instead.",
            source_loc=source_loc,
        )
    else:
        chain = " -> ".join(cycle + [cycle[0]])
        raise CodegenError(
            f"FixedStack ABI does not support recursive functions. "
            f"Mutual recursion detected: {chain}. "
            f"Use '--abi Default' instead.",
            source_loc=source_loc,
        )


def _promote_function_params(
    func: MIRFunction, scratch_pool: ScratchRegisterPool
) -> Dict[int, Tuple[str, object]]:
    """
    Promote all stack parameters of a function to hw regs or scratch.

    Returns:
        Dict mapping param_idx -> ('hw', reg_name) or ('scratch', scratch_addr)

    Raises:
        CodegenError: If any parameter cannot be placed
    """
    if not func.stack_param_offsets:
        return {}

    from r65.compiler.mir.liveness import InstructionLivenessAnalyzer
    from r65.compiler.hir.types import PointerTypeInfo

    liveness = InstructionLivenessAnalyzer(func)

    # Determine which hw regs are already taken by explicit bindings
    taken_hw_regs: Set[str] = set()
    for param in func.parameters:
        from r65.compiler.hir.nodes import RegisterBinding
        if isinstance(param.binding, RegisterBinding):
            taken_hw_regs.add(param.binding.register_name)

    # Also account for trait method self in Y
    if func.is_trait_method:
        taken_hw_regs.add('Y')

    # Classify each stack param
    params_to_place: List[Tuple[int, VirtualRegister, int, bool]] = []  # (idx, vreg, size, cross_call)
    for param_idx in sorted(func.stack_param_offsets.keys()):
        vreg = func.param_to_vreg.get(param_idx)
        if vreg is None:
            continue
        param_size = get_type_size(func.parameters[param_idx].param_type)
        cross_call = liveness.is_live_across_any_call(vreg)

        # Far pointers (3 bytes) can only go to scratch, not hw regs
        is_far_ptr = isinstance(func.parameters[param_idx].param_type, PointerTypeInfo) and \
                     func.parameters[param_idx].param_type.is_far

        if is_far_ptr:
            # Force to scratch only
            params_to_place.append((param_idx, vreg, param_size, cross_call))
        else:
            params_to_place.append((param_idx, vreg, param_size, cross_call))

    # Available hw regs for promotion (order: A, B for u8; X, Y for u16)
    # B is only usable in m8 mode — exclude it from m16 functions (@ A: u16)
    # because in m16, B is the high byte of the 16-bit accumulator and
    # every accumulator operation clobbers it.
    func_is_m16 = any(
        isinstance(p.binding, RegisterBinding) and p.binding.register_name == 'A'
        and get_type_size(p.param_type) == 2
        for p in func.parameters
    )
    available_hw_u8 = [r for r in ['A', 'B'] if r not in taken_hw_regs]
    if func_is_m16:
        available_hw_u8 = [r for r in available_hw_u8 if r != 'B']
    available_hw_u16 = [r for r in ['X', 'Y'] if r not in taken_hw_regs]

    # Available scratch registers
    scratch_available = [(s.address, s.size, s.name) for s in scratch_pool.scratches]
    used_scratches: Set[int] = set()

    result: Dict[int, Tuple[str, object]] = {}

    # First pass: assign cross-call params to hw regs (they have existing region-spill support)
    #   - Only A, X, Y are safe (B has no spill support, callees clobber it via m16 ops)
    #   - Scratch registers are NOT safe (callees allocate their own locals to same DP addresses)
    # Second pass: assign local params to hw regs (incl. B), then scratch
    for is_cross_call_pass in [True, False]:
        for param_idx, vreg, param_size, cross_call in params_to_place:
            if param_idx in result:
                continue
            if cross_call != is_cross_call_pass:
                continue

            # Check if this is a far pointer (3 bytes) — scratch only
            is_far_ptr = param_idx in func.far_ptr_param_indices

            placed = False

            # Try hw regs first (not for far pointers)
            if not is_far_ptr:
                if param_size <= 1:
                    # u8/i8 → try A, then B (B only for non-cross-call params)
                    for reg in available_hw_u8:
                        if is_cross_call_pass and reg == 'B':
                            continue  # B has no region-spill support
                        result[param_idx] = ('hw', reg)
                        available_hw_u8.remove(reg)
                        placed = True
                        break
                elif param_size == 2:
                    # u16/i16 → try X, then Y
                    for reg in available_hw_u16:
                        result[param_idx] = ('hw', reg)
                        available_hw_u16.remove(reg)
                        placed = True
                        break

            # Try scratch registers if hw failed
            if not placed:
                for addr, size, name in scratch_available:
                    if addr in used_scratches:
                        continue
                    if size >= param_size:
                        result[param_idx] = ('scratch', addr)
                        used_scratches.add(addr)
                        placed = True
                        break

            # Try composite: find adjacent free scratches that together cover param_size
            if not placed:
                composite = find_composite_scratch(scratch_available, used_scratches, param_size)
                if composite:
                    base_addr = composite[0][0]
                    result[param_idx] = ('scratch', base_addr)
                    for addr, _, _ in composite:
                        used_scratches.add(addr)
                    placed = True

            if not placed:
                param_name = func.parameters[param_idx].name
                raise CodegenError(
                    f"FixedStack ABI: cannot place parameter '{param_name}' (index {param_idx}) "
                    f"of function '{func.name}'. All hardware registers and scratch registers "
                    f"are exhausted. Add explicit register bindings or reduce parameter count.",
                    source_loc=func.source_loc,
                )

    return result


def _inject_hw_param_moves(func: MIRFunction):
    """
    Inject Move(hw_reg -> vreg) instructions at the start of the entry block
    for hw-promoted parameters.

    These are analogous to the Move instructions that the MIR builder emits
    for explicitly register-bound parameters (e.g., `param @ A: u8`).
    """
    if not func.hw_param_regs:
        return

    entry_block = func.blocks[func.entry_block_id]
    moves_to_inject = []

    for param_idx, hw_reg_name in sorted(func.hw_param_regs.items()):
        vreg = func.param_to_vreg.get(param_idx)
        if vreg is None:
            continue
        param_type = func.parameters[param_idx].param_type
        move = Move(
            dest=vreg,
            source=HardwareRegister(hw_reg_name),
            type_info=param_type,
        )
        moves_to_inject.append(move)

    # Insert moves at the beginning of the entry block
    # (after any existing register-param moves, but before other instructions)
    # To keep it simple, just prepend them — register-param moves are already
    # at the start, and order among hw-promoted moves doesn't matter much
    # as long as they come before the first use.
    entry_block.instructions = moves_to_inject + entry_block.instructions


def _update_call_sites(func: MIRFunction, all_promotions: Dict[str, Dict[int, Tuple[str, object]]]):
    """
    Update Call instructions to use REGISTER or SCRATCH_PARAM mechanism
    for promoted parameters.
    """
    for block in func.blocks.values():
        for instr in block.instructions:
            if not isinstance(instr, (Call, TraitDispatch)):
                continue

            # TraitDispatch doesn't have a static callee — skip
            if isinstance(instr, TraitDispatch):
                continue

            # Only direct calls (not indirect through function pointer)
            if not isinstance(instr.function, str):
                continue

            callee_promos = all_promotions.get(instr.function)
            if not callee_promos:
                continue

            for arg_idx, arg in enumerate(instr.args):
                if arg.mechanism != ArgumentMechanism.STACK:
                    continue
                if arg_idx not in callee_promos:
                    continue

                kind, loc = callee_promos[arg_idx]
                if kind == 'hw':
                    arg.mechanism = ArgumentMechanism.REGISTER
                    arg.location = HardwareRegister(loc)
                elif kind == 'scratch':
                    arg.mechanism = ArgumentMechanism.SCRATCH_PARAM
                    arg.scratch_addr = loc
