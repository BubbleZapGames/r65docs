"""
Call instruction selector: Function calls and built-ins.

Handles function call generation including argument setup, call emission,
return value collection, and built-in function expansion.

Includes hardware register spill/reload around calls based on liveness
and callee's #[preserves()] attribute.

Region-based spilling (Phase 2):
Instead of spilling around each call, we identify "clobber regions" -
maximal sequences of calls where a register is live but not used. We save
once at the start of the region and restore once at the end, reducing
redundant push/pull operations.
"""

from typing import List, Set, Dict, NamedTuple, Optional, TYPE_CHECKING
from r65.compiler.mir.nodes import Call, TraitDispatch, VirtualRegister, ArgumentMechanism, Immediate as MIRImmediate

if TYPE_CHECKING:
    from r65.compiler.mir.liveness import ClobberRegion
from r65.compiler.codegen.register_alloc import LocationKind
from r65.compiler.codegen.opcodes import (
    Opcode, TRANSFER_OPCODES, PUSH_OPCODES, PULL_OPCODES,
    LOAD_IMMEDIATE_OPCODES, STORE_MNEMONICS, BUILTIN_OPCODES
)
from r65.compiler.codegen.asm_nodes import BlockMove
from r65.compiler.errors import InstructionSelectionError
from r65.compiler.codegen.errors import (
    unknown_value, argument_count_error, requires_constant
)
from r65.compiler.codegen.base_selector import BaseSelector


class SpillInfo(NamedTuple):
    """Information about a hardware register that needs spilling."""
    vreg: Optional[VirtualRegister]  # The virtual register allocated to the hw reg, or None for direct hw reg usage
    hw_reg: str            # Hardware register name ('A', 'X', 'Y')
    spill_mode: Optional[int] = None  # For A register: mode at spill time (8 or 16), None for X/Y
    # Stack spill location will be managed via push/pull


class ActiveRegionState:
    """
    Tracks active clobber regions during code generation.

    For each hardware register (X, Y), tracks whether we're currently inside
    a clobber region (have saved but not yet restored).

    Also tracks the current "spill offset" - the number of bytes pushed onto
    the stack for spilling. This is used to adjust stack-relative accesses
    to local variables while spills are active.
    """

    def __init__(self):
        # Map from hw_reg ('X', 'Y') to the ClobberRegion we're inside, or None
        self.active_regions: Dict[str, 'ClobberRegion'] = {}
        # Pre-computed regions for current block: block_id -> {hw_reg -> [ClobberRegion]}
        self.block_regions: Dict[int, Dict[str, List['ClobberRegion']]] = {}
        # Current block ID
        self.current_block_id: Optional[int] = None
        # Current spill offset - bytes pushed onto stack for spilling
        # Used to adjust stack-relative accesses while spills are active
        self.spill_offset: int = 0
        # Track pending A spill info for reload (need to restore mode)
        self.pending_a_spill: Optional[SpillInfo] = None

    def set_block_regions(self, block_id: int, regions: Dict[str, List['ClobberRegion']]):
        """Set pre-computed regions for a block."""
        self.block_regions[block_id] = regions
        self.current_block_id = block_id
        # Clear active regions when entering new block
        self.active_regions.clear()
        # Reset spill offset for new block
        self.spill_offset = 0

    def get_region_for_call(self, hw_reg: str, call_idx: int) -> Optional['ClobberRegion']:
        """
        Get the clobber region that contains this call for the given register.

        Args:
            hw_reg: Hardware register ('X' or 'Y')
            call_idx: Instruction index of the call

        Returns:
            ClobberRegion if call is in a region, None otherwise
        """
        if self.current_block_id is None:
            return None

        regions = self.block_regions.get(self.current_block_id, {}).get(hw_reg, [])
        for region in regions:
            if call_idx in region.clobbering_calls:
                return region
        return None

    def is_first_call_in_region(self, hw_reg: str, call_idx: int) -> bool:
        """Check if this call is the first clobbering call in its region."""
        region = self.get_region_for_call(hw_reg, call_idx)
        if region is None:
            return False
        return region.clobbering_calls[0] == call_idx

    def is_last_call_in_region(self, hw_reg: str, call_idx: int) -> bool:
        """Check if this call is the last clobbering call in its region."""
        region = self.get_region_for_call(hw_reg, call_idx)
        if region is None:
            return False
        return region.clobbering_calls[-1] == call_idx

    def mark_region_active(self, hw_reg: str, region: 'ClobberRegion'):
        """Mark that we've saved for this region (entered it)."""
        self.active_regions[hw_reg] = region

    def is_region_active(self, hw_reg: str) -> bool:
        """Check if we're inside an active region for this register."""
        return hw_reg in self.active_regions

    def get_active_region(self, hw_reg: str) -> Optional['ClobberRegion']:
        """Get the active region for this register, if any."""
        return self.active_regions.get(hw_reg)

    def clear_active_region(self, hw_reg: str):
        """Mark that we've restored for this region (exited it)."""
        if hw_reg in self.active_regions:
            del self.active_regions[hw_reg]


class CallInstructionSelector(BaseSelector):
    """
    Handles call instruction selection.

    Manages generation of function calls, built-in expansions,
    and indirect call trampolines.

    Uses region-based spilling (Phase 2): instead of spilling around each call,
    identifies "clobber regions" and saves once at region start, restores once
    at region end.
    """

    def __init__(self, parent):
        """Initialize call instruction selector with region tracking state."""
        super().__init__(parent)
        # Region tracking state for optimized spilling
        self._region_state = ActiveRegionState()
        # Pre-computed regions for current function: {block_id: {hw_reg: [ClobberRegion]}}
        self._function_regions: Optional[Dict[int, Dict[str, List]]] = None
        # Whether A is bound to a vreg (uses region-based spilling if True)
        self._a_bound_to_vreg: bool = False

    def initialize_regions_for_function(self):
        """
        Pre-compute clobber regions for all blocks in the current function.

        Should be called once per function before processing any blocks.
        """
        reg_alloc = self.parent.reg_alloc
        if not reg_alloc or not reg_alloc.instr_liveness:
            self._function_regions = None
            self._a_bound_to_vreg = False
            return

        from r65.compiler.mir.liveness import ClobberRegionAnalyzer

        # Build preserves map from function signatures in the current function
        preserves_map = self._build_preserves_map()

        # Check if A is bound to a vreg (e.g., function parameter @ A)
        # If so, include A in region-based spilling
        a_alloc = reg_alloc.get_hw_alloc('A')
        self._a_bound_to_vreg = a_alloc.allocated_vreg is not None

        analyzer = ClobberRegionAnalyzer(reg_alloc.instr_liveness)
        self._function_regions = analyzer.analyze_function(
            preserves_map,
            include_a=self._a_bound_to_vreg
        )

    def initialize_regions_for_block(self, block_id: int):
        """
        Initialize region tracking state for a specific block.

        Should be called when starting to process a new block.

        Args:
            block_id: The block ID being processed
        """
        if self._function_regions is None:
            # No pre-computed regions, will fall back to per-call spilling
            self._region_state = ActiveRegionState()
            return

        default_regions = {'A': [], 'X': [], 'Y': []} if self._a_bound_to_vreg else {'X': [], 'Y': []}
        regions = self._function_regions.get(block_id, default_regions)
        self._region_state.set_block_regions(block_id, regions)

    def _build_preserves_map(self) -> Dict[str, Set[str]]:
        """
        Build a map from function names to their preserved registers.

        Returns:
            Dictionary mapping function name to set of preserved register names
        """
        preserves_map: Dict[str, Set[str]] = {}

        # Scan all call instructions in the function to build the map
        if self.parent.current_function:
            for block in self.parent.current_function.blocks.values():
                for instr in block.instructions:
                    if isinstance(instr, Call) and isinstance(instr.function, str):
                        if instr.preserves_attr:
                            func_name = instr.function
                            preserves_map[func_name] = set(instr.preserves_attr.registers)

        return preserves_map

    # ========================================================================
    # Call-Specific Emission Helpers
    # ========================================================================

    def _emit_transfer(self, source: str, dest: str):
        """Emit a register transfer instruction."""
        opcode = TRANSFER_OPCODES.get((source, dest))
        if opcode:
            self._emit_implied(opcode)

    def _emit_push(self, reg: str, comment: str = None):
        """Emit a push instruction."""
        opcode = PUSH_OPCODES.get(reg)
        if opcode:
            self._emit_implied(opcode, comment)

    def _emit_pull(self, reg: str, comment: str = None):
        """Emit a pull instruction."""
        opcode = PULL_OPCODES.get(reg)
        if opcode:
            self._emit_implied(opcode, comment)

    def _emit_load_immediate(self, reg: str, value: int, comment: str = None):
        """Emit a load immediate instruction."""
        opcode = LOAD_IMMEDIATE_OPCODES.get(reg)
        if opcode:
            self._emit_immediate(opcode, value, comment)

    def _ensure_m8_mode(self, comment: str = "8-bit A"):
        """Switch to 8-bit accumulator mode if not already there."""
        from r65.compiler.codegen.constants import M_FLAG
        if self.parent.emitter.get_accu_mode() != 8:
            self._emit_immediate(Opcode.SEP_IMMEDIATE, M_FLAG, comment)
            self.parent.emitter.emit_accu_mode(8)

    def _push_multibyte_value(self, arg_loc, source_size: int, target_size: int, is_stack: bool):
        """
        Push a multi-byte value to stack with zero-extension as needed.

        Handles stack drift compensation for stack-based source locations.
        Bytes are pushed high-to-low (bank first for 24-bit, high first for 16-bit).

        Args:
            arg_loc: Source location
            source_size: Size of source value in bytes
            target_size: Size of target parameter in bytes
            is_stack: True if arg_loc is on stack (needs drift compensation)
        """
        push_count = 0  # Track pushes for stack drift compensation

        # Push bytes from high to low
        for byte_idx in range(target_size - 1, -1, -1):
            if byte_idx >= source_size:
                # Zero-extend: push 0 for bytes beyond source size
                byte_name = {2: "bank", 1: "high", 0: "low"}.get(byte_idx, f"byte{byte_idx}")
                self._emit_load_immediate('A', 0, f"Zero-extend {byte_name} byte")
                self._emit_push('A', f"Push {byte_name} byte (zero)")
            else:
                # Load from source location
                byte_name = {2: "bank", 1: "high", 0: "low"}.get(byte_idx, f"byte{byte_idx}")
                offset = byte_idx
                if is_stack:
                    offset += push_count  # Compensate for stack drift
                if offset > 0:
                    loc = self.parent._offset_location(arg_loc, offset)
                else:
                    loc = arg_loc
                self.parent._emit_load('LDA', loc, f"Load {byte_name} byte")
                self._emit_push('A', f"Push {byte_name} byte")
            push_count += 1

    # ========================================================================
    # Main Call Selection
    # ========================================================================

    def select_call(self, instr: Call):
        """
        Generate code for Call instruction.

        Handles argument setup, call, and return value collection.
        Also handles built-in function calls.

        Cross-mode call handling:
        - Before call: switch to callee's entry mode if different from current
        - After call: caller receives return value in callee's exit mode
        - After using return value: switch back to m8 (default mode)

        Hardware register spilling:
        - Before call: spill hw registers that are live across call and not preserved
        - After call: reload those registers

        Args:
            instr: Call instruction
        """
        # Handle built-in functions
        if instr.builtin_name:
            self._emit_builtin_call(instr)
            return

        # Check if we need D register management for far pointer params
        needs_d_management = (
            self.parent.current_function and
            self.parent.current_function.has_far_ptr_stack_params
        )

        # Step 0: Compute hardware register spills needed
        # Spill hw registers that are live across this call and not preserved by callee
        spills = self._compute_hw_spills(instr)

        # Step 0.5: Emit spills BEFORE argument setup (to avoid clobbering args)
        self._emit_hw_spills(spills)

        # Step 0.7: Restore D register BEFORE argument setup (for far pointer functions)
        # CRITICAL: PLD must happen before pushing arguments. If PLD happens after,
        # it pops 2 bytes from the top of the stack, consuming part of the just-pushed
        # arguments instead of the saved D value.
        # After PLD, S increases by 2, so all stack-relative source offsets during
        # argument setup must be adjusted by -2.
        pre_arg_stack_adj = 0
        if needs_d_management:
            self._emit_d_restore_before_call()
            pre_arg_stack_adj = -2  # PLD popped 2 bytes, S increased by 2

        # Step 1: Set up arguments (with stack offset adjustment if D was popped)
        stack_bytes_pushed = self._emit_argument_setup(instr, pre_arg_stack_adj)

        # Step 2: Handle caller-managed DBR (databank=caller)
        needs_dbr_restore = self._emit_caller_dbr_setup(instr)

        # Step 2.6: Switch to callee's entry mode if needed
        # Callee's prologue expects to be in entry_m_mode
        self._emit_entry_mode_switch(instr)

        # Step 3: Make the call
        self._emit_call_instruction(instr, stack_bytes_pushed)

        # Invalidate XBA state after call (function may have modified A/B)
        self.parent._invalidate_xba_state()

        # Step 3.5: Update emitter mode to reflect callee's exit mode
        # This is critical - the callee may exit in a different mode than entry
        self._update_mode_after_call(instr)

        # Step 4: Restore DBR if caller-managed
        if needs_dbr_restore:
            self._emit_pull('B', "Restore data bank (caller)")

        # Step 5: Stack arguments are cleaned up by callee (not caller)
        # The callee's epilogue handles stack parameter cleanup before RTS/RTL

        # Step 6: Collect return values (in callee's exit mode)
        self._emit_return_value_collection(instr)

        # Step 7: Restore mode after receiving return value
        # If callee exited in m16 (u16 return), switch back to m8
        self._emit_exit_mode_restore(instr)

        # Step 7.5: Reload spilled hardware registers (region-based)
        # Only reload registers where this is the last call in the region
        reloads = self._compute_hw_reloads(instr)
        self._emit_hw_reloads(reloads)

        # Step 8: Restore D to stack and optionally re-establish D = S
        if needs_d_management:
            # We used PLD before the call, so we must push D back
            # If there are more far pointer dereferences, also set D = S
            if self._has_far_ptr_derefs_after_call(instr):
                self._emit_d_equals_s_restore()  # PHD + TSC + TCD
            else:
                self._emit_d_push_only()  # Just PHD (for epilogue)

    # ========================================================================
    # Trait Dispatch
    # ========================================================================

    def select_trait_dispatch(self, instr: TraitDispatch):
        """
        Generate code for TraitDispatch instruction.

        Emits argument setup, then JSR to the dispatch wrapper function.
        The dispatch wrapper (generated separately) loads TypeId and jumps
        to the concrete implementation via a jump table.

        Args:
            instr: TraitDispatch instruction
        """
        # Trait dispatch is treated like a regular call to the dispatch wrapper.
        # The wrapper function is generated in codegen.py and handles the
        # TypeId lookup and jump table dispatch.
        dispatch_name = f"{instr.trait_name}__{instr.method_name}__dispatch"

        # Compute hw register spills (no preserves_attr for trait dispatch)
        spills = self._compute_trait_dispatch_spills(instr)
        self._emit_hw_spills(spills)

        # Set up arguments (same mechanism as regular calls)
        stack_bytes_pushed = self._emit_trait_dispatch_args(instr)

        # Emit the call to the dispatch wrapper
        if instr.is_far:
            self._emit_address(Opcode.JSL, dispatch_name)
        else:
            self._emit_address(Opcode.JSR, dispatch_name)

        # Invalidate XBA state after dispatch
        self.parent._invalidate_xba_state()

        # Collect return values (reuse existing helper - works with any instr
        # that has .returns and callee_return_type)
        self._emit_return_value_collection(instr)

        # Reload spilled registers
        reloads = self._compute_trait_dispatch_reloads(instr)
        self._emit_hw_reloads(reloads)

    def _compute_trait_dispatch_spills(self, instr: TraitDispatch) -> List[SpillInfo]:
        """Compute hw register spills for trait dispatch (no preserves)."""
        spills: List[SpillInfo] = []
        reg_alloc = self.parent.reg_alloc
        if not reg_alloc:
            return spills

        instr_idx = None
        if reg_alloc.instr_liveness:
            pos = reg_alloc.instr_liveness.get_instruction_position(instr)
            if pos:
                _, instr_idx = pos

        # Determine return registers
        return_regs = self._get_callee_return_registers(instr)
        callee_return_type = getattr(instr, 'callee_return_type', None)
        if callee_return_type is not None:
            from r65.compiler.hir.types import TupleTypeInfo
            if isinstance(callee_return_type, TupleTypeInfo):
                num_returns = len(callee_return_type.element_types)
            else:
                num_returns = 1
        else:
            num_returns = len(instr.returns)
        call_return_set = set(return_regs[:num_returns])

        for reg_name in ['A', 'X', 'Y']:
            if reg_name in call_return_set:
                continue

            use_region_based = (
                instr_idx is not None and
                self._function_regions is not None and
                (reg_name in ('X', 'Y') or (reg_name == 'A' and self._a_bound_to_vreg))
            )

            if use_region_based:
                region = self._region_state.get_region_for_call(reg_name, instr_idx)
                if region is not None:
                    if self._region_state.is_first_call_in_region(reg_name, instr_idx):
                        spills.append(SpillInfo(vreg=None, hw_reg=reg_name))
                        self._region_state.mark_region_active(reg_name, region)
                    continue

            hw_alloc = reg_alloc.get_hw_alloc(reg_name)
            vreg = hw_alloc.allocated_vreg

            if vreg is not None:
                if reg_alloc.instr_liveness:
                    pos = reg_alloc.instr_liveness.get_instruction_position(instr)
                    if pos:
                        block_id, idx = pos
                        if reg_alloc.instr_liveness.is_live_after(vreg, block_id, idx):
                            spills.append(SpillInfo(vreg=vreg, hw_reg=reg_name))
                else:
                    if hw_alloc.is_bound:
                        spills.append(SpillInfo(vreg=vreg, hw_reg=reg_name))
                continue

            if reg_name in ('X', 'Y') and reg_alloc.instr_liveness and self._function_regions is None:
                pos = reg_alloc.instr_liveness.get_instruction_position(instr)
                if pos:
                    block_id, idx = pos
                    if reg_alloc.instr_liveness.is_hw_reg_live_after(reg_name, block_id, idx):
                        spills.append(SpillInfo(vreg=None, hw_reg=reg_name))

        return spills

    def _compute_trait_dispatch_reloads(self, instr: TraitDispatch) -> List[SpillInfo]:
        """Compute hw register reloads after trait dispatch."""
        reloads: List[SpillInfo] = []
        reg_alloc = self.parent.reg_alloc
        if not reg_alloc:
            return reloads

        # Skip return registers — they hold the call result, not the spilled value
        return_regs = self._get_callee_return_registers(instr)
        callee_return_type = getattr(instr, 'callee_return_type', None)
        if callee_return_type is not None:
            from r65.compiler.hir.types import TupleTypeInfo
            if isinstance(callee_return_type, TupleTypeInfo):
                num_returns = len(callee_return_type.element_types)
            else:
                num_returns = 1
        else:
            num_returns = len(instr.returns)
        call_return_set = set(return_regs[:num_returns])

        instr_idx = None
        if reg_alloc.instr_liveness:
            pos = reg_alloc.instr_liveness.get_instruction_position(instr)
            if pos:
                _, instr_idx = pos

        for reg_name in ['A', 'X', 'Y']:
            if reg_name in call_return_set:
                continue

            use_region_based = (
                instr_idx is not None and
                self._function_regions is not None and
                (reg_name in ('X', 'Y') or (reg_name == 'A' and self._a_bound_to_vreg))
            )

            if use_region_based:
                region = self._region_state.get_region_for_call(reg_name, instr_idx)
                if region is not None:
                    if self._region_state.is_last_call_in_region(reg_name, instr_idx):
                        reloads.append(SpillInfo(vreg=None, hw_reg=reg_name))
                        self._region_state.mark_region_inactive(reg_name)
                    continue

            hw_alloc = reg_alloc.get_hw_alloc(reg_name)
            vreg = hw_alloc.allocated_vreg
            if vreg is not None:
                if reg_alloc.instr_liveness:
                    pos = reg_alloc.instr_liveness.get_instruction_position(instr)
                    if pos:
                        block_id, idx = pos
                        if reg_alloc.instr_liveness.is_live_after(vreg, block_id, idx):
                            reloads.append(SpillInfo(vreg=vreg, hw_reg=reg_name))
                else:
                    if hw_alloc.is_bound:
                        reloads.append(SpillInfo(vreg=vreg, hw_reg=reg_name))
                continue

            if reg_name in ('X', 'Y') and reg_alloc.instr_liveness and self._function_regions is None:
                pos = reg_alloc.instr_liveness.get_instruction_position(instr)
                if pos:
                    block_id, idx = pos
                    if reg_alloc.instr_liveness.is_hw_reg_live_after(reg_name, block_id, idx):
                        reloads.append(SpillInfo(vreg=None, hw_reg=reg_name))

        return reloads

    def _emit_trait_dispatch_args(self, instr: TraitDispatch) -> int:
        """Emit argument setup for trait dispatch.

        Self pointer is passed in Y (SELF_Y mechanism), other args are stack-passed.
        Stack args are pushed first, then Y is loaded with self address last.
        """
        from r65.compiler.codegen.type_utils import get_type_size
        from r65.compiler.codegen.constants import M_FLAG

        stack_bytes_pushed = 0
        stack_args = [arg for arg in instr.args if arg.mechanism == ArgumentMechanism.STACK]
        self_y_arg = None
        for arg in instr.args:
            if arg.mechanism == ArgumentMechanism.SELF_Y:
                self_y_arg = arg
                break

        # Push stack arguments in reverse order (last param first)
        for arg in reversed(stack_args):
            arg_loc = self.parent._get_operand_location(arg.value)

            if arg_loc.kind == LocationKind.STACK and stack_bytes_pushed > 0:
                arg_loc = self.parent._offset_location(arg_loc, stack_bytes_pushed)

            self._emit_stack_argument(arg, arg_loc)
            arg_size = 1
            if arg.param_type is not None:
                arg_size = get_type_size(arg.param_type)
            elif hasattr(arg.value, 'type_info') and arg.value.type_info:
                arg_size = get_type_size(arg.value.type_info)
            stack_bytes_pushed += arg_size

        # Load Y with self pointer address (after stack args, before JSR/JSL)
        if self_y_arg is not None:
            self._load_y_with_self(self_y_arg, stack_bytes_pushed)

        return stack_bytes_pushed

    def _load_y_with_self(self, arg: 'Argument', stack_bytes_pushed: int):
        """Load Y register with the self pointer address for trait dispatch.

        Handles different source locations:
        - Scratch/DP: LDY dp_addr
        - Stack: REP #$20; LDA d,S; TAY; SEP #$20 (no LDY d,S on 65816)
        - Hardware (X): TXY
        - Immediate: LDY #imm
        - Memory: LDY abs_addr
        """
        from r65.compiler.codegen.constants import M_FLAG

        arg_loc = self.parent._get_operand_location(arg.value)

        # Adjust for stack args that were pushed
        if arg_loc.kind == LocationKind.STACK and stack_bytes_pushed > 0:
            arg_loc = self.parent._offset_location(arg_loc, stack_bytes_pushed)

        if isinstance(arg.value, MIRImmediate):
            # Immediate address
            self.parent._emit_immediate(Opcode.LDY_IMMEDIATE, arg.value.value, "Load self ptr into Y")
        elif arg_loc.kind == LocationKind.HARDWARE:
            if arg_loc.hw_register == 'Y':
                pass  # Already in Y
            elif arg_loc.hw_register == 'X':
                self.parent.emitter.emit_raw("    TXY")
            elif arg_loc.hw_register == 'A':
                self.parent.emitter.emit_raw("    TAY")
            else:
                raise InstructionSelectionError(f"Cannot load Y from hardware register {arg_loc.hw_register}", source_loc=self.parent._current_source_loc)
        elif arg_loc.kind == LocationKind.SCRATCH:
            # Scratch (direct page) location — LDY dp
            self.parent._emit_load('LDY', arg_loc, "Load self ptr into Y")
        elif arg_loc.kind == LocationKind.STACK:
            # Stack-relative: no LDY d,S exists on 65816
            # Use: REP #$20; LDA d,S; TAY; SEP #$20
            self.parent._emit_immediate(Opcode.REP_IMMEDIATE, M_FLAG, "16-bit A for stack self load")
            self.parent.emitter.emit_accu_mode(16)
            self.parent._emit_load('LDA', arg_loc, "Load self ptr from stack")
            self.parent.emitter.emit_raw("    TAY")
            self.parent._emit_immediate(Opcode.SEP_IMMEDIATE, M_FLAG, "Restore 8-bit A")
            self.parent.emitter.emit_accu_mode(8)
        elif arg_loc.kind == LocationKind.MEMORY:
            # Absolute memory location
            self.parent._emit_load('LDY', arg_loc, "Load self ptr into Y")
        else:
            raise InstructionSelectionError(f"Cannot load Y from location kind {arg_loc.kind}", source_loc=self.parent._current_source_loc)

    # ========================================================================
    # Hardware Register Spill/Reload (Region-Based)
    # ========================================================================

    def _compute_hw_spills(self, instr: Call) -> List[SpillInfo]:
        """
        Compute which hardware registers need spilling for this call.

        Uses region-based analysis when available: only returns registers that
        need to START a new region at this call. Registers that are already
        in an active region (saved earlier) are not included.

        Falls back to per-call analysis when region analysis is unavailable.

        Args:
            instr: The Call instruction

        Returns:
            List of SpillInfo for registers that need spilling at THIS call
        """
        spills: List[SpillInfo] = []

        # Get callee's preserved registers
        preserved: Set[str] = set()
        if instr.preserves_attr:
            preserved = set(instr.preserves_attr.registers)

        # Check each hardware register
        reg_alloc = self.parent.reg_alloc
        if not reg_alloc:
            return spills

        # Get instruction position for region lookup
        instr_idx = None
        if reg_alloc.instr_liveness:
            pos = reg_alloc.instr_liveness.get_instruction_position(instr)
            if pos:
                _, instr_idx = pos

        # Determine which registers receive return values from this call.
        # A call that defines a register via return should never be spilled —
        # spilling would save garbage and PLX/PLY would clobber the return value.
        # Note: instr.returns may be empty (return values captured by separate Move
        # instructions), so we determine the count from callee_return_type.
        return_regs = self._get_callee_return_registers(instr)
        callee_return_type = getattr(instr, 'callee_return_type', None)
        if callee_return_type is not None:
            from r65.compiler.hir.types import TupleTypeInfo
            if isinstance(callee_return_type, TupleTypeInfo):
                num_returns = len(callee_return_type.element_types)
            else:
                num_returns = 1
        else:
            num_returns = len(instr.returns)
        call_return_set = set(return_regs[:num_returns])

        for reg_name in ['A', 'X', 'Y']:
            # Skip if callee preserves this register
            if reg_name in preserved:
                continue

            # Skip if this call returns a value in this register
            if reg_name in call_return_set:
                continue

            # Check if region-based spilling is available for this register
            # - X/Y always use region-based when available
            # - A uses region-based only when bound to a vreg
            use_region_based = (
                instr_idx is not None and
                self._function_regions is not None and
                (reg_name in ('X', 'Y') or (reg_name == 'A' and self._a_bound_to_vreg))
            )

            if use_region_based:
                # Check if this call is in a region for this register
                region = self._region_state.get_region_for_call(reg_name, instr_idx)

                if region is not None:
                    # This call is in a clobber region
                    if self._region_state.is_first_call_in_region(reg_name, instr_idx):
                        # First call in region - need to spill
                        spills.append(SpillInfo(vreg=None, hw_reg=reg_name))
                        # Mark region as active
                        self._region_state.mark_region_active(reg_name, region)
                    # Else: already in active region, no spill needed
                    continue

            # Fall back to per-call analysis for A (when not bound) or when no region
            hw_alloc = reg_alloc.get_hw_alloc(reg_name)
            vreg = hw_alloc.allocated_vreg

            # Case 1: Vreg allocated to this hw register
            if vreg is not None:
                # Check if the vreg is live after this call
                if reg_alloc.instr_liveness:
                    pos = reg_alloc.instr_liveness.get_instruction_position(instr)
                    if pos:
                        block_id, idx = pos
                        if reg_alloc.instr_liveness.is_live_after(vreg, block_id, idx):
                            spills.append(SpillInfo(vreg=vreg, hw_reg=reg_name))
                else:
                    # Conservative: assume live if we have an allocation
                    if hw_alloc.is_bound:
                        spills.append(SpillInfo(vreg=vreg, hw_reg=reg_name))
                continue

            # Case 2: Direct hardware register usage (X and Y only, not A)
            # For X/Y without region info, fall back to per-call
            if reg_name in ('X', 'Y') and reg_alloc.instr_liveness and self._function_regions is None:
                pos = reg_alloc.instr_liveness.get_instruction_position(instr)
                if pos:
                    block_id, idx = pos
                    if reg_alloc.instr_liveness.is_hw_reg_live_after(reg_name, block_id, idx):
                        spills.append(SpillInfo(vreg=None, hw_reg=reg_name))

        return spills

    def _compute_hw_reloads(self, instr: Call) -> List[SpillInfo]:
        """
        Compute which hardware registers need reloading after this call.

        Uses region-based analysis for X/Y: only returns registers where this call
        is the LAST clobbering call in the region.

        For A register: uses per-call spilling - reload if it was spilled for this call.

        Args:
            instr: The Call instruction

        Returns:
            List of SpillInfo for registers that need reloading after THIS call
        """
        reloads: List[SpillInfo] = []

        reg_alloc = self.parent.reg_alloc
        if not reg_alloc or not reg_alloc.instr_liveness:
            # If A was spilled, still need to reload it
            if self._region_state.pending_a_spill is not None:
                reloads.append(self._region_state.pending_a_spill)
            return reloads

        # Get instruction position
        pos = reg_alloc.instr_liveness.get_instruction_position(instr)
        if not pos:
            if self._region_state.pending_a_spill is not None:
                reloads.append(self._region_state.pending_a_spill)
            return reloads

        _, instr_idx = pos

        # Check each active region for X/Y and A (when bound)
        regs_to_check = ('A', 'X', 'Y') if self._a_bound_to_vreg else ('X', 'Y')
        for hw_reg in regs_to_check:
            if self._region_state.is_region_active(hw_reg):
                if self._region_state.is_last_call_in_region(hw_reg, instr_idx):
                    # Last call in region - need to reload
                    reloads.append(SpillInfo(vreg=None, hw_reg=hw_reg))
                    # Clear active region
                    self._region_state.clear_active_region(hw_reg)

        # A register per-call spilling (only when NOT using region-based)
        # This handles the case where A is used but not bound to a vreg
        if not self._a_bound_to_vreg and self._region_state.pending_a_spill is not None:
            reloads.append(self._region_state.pending_a_spill)

        return reloads

    def _emit_hw_spills(self, spills: List[SpillInfo]):
        """
        Emit push instructions to spill hardware registers.

        For region-based spilling, this is only called at region start.
        Updates the spill offset to track stack growth for adjusting
        stack-relative accesses.

        Args:
            spills: List of registers to spill
        """
        for spill in spills:
            if spill.hw_reg == 'A':
                # A register size depends on current mode
                current_mode = self.parent.emitter.get_accu_mode()
                # Create spill info with mode recorded
                spill_with_mode = SpillInfo(
                    vreg=spill.vreg,
                    hw_reg=spill.hw_reg,
                    spill_mode=current_mode
                )
                self._emit_push('A', f"Spill A (m{current_mode})")
                # Track stack growth based on actual mode
                if current_mode == 16:
                    self._region_state.spill_offset += 2
                else:
                    self._region_state.spill_offset += 1
                # Save spill info for reload
                self._region_state.pending_a_spill = spill_with_mode
            else:
                # X/Y are always 16-bit (2 bytes)
                self._emit_push(spill.hw_reg, f"Spill {spill.hw_reg} (region start)")
                self._region_state.spill_offset += 2

    def _emit_hw_reloads(self, spills: List[SpillInfo]):
        """
        Emit pull instructions to reload spilled hardware registers.

        Must be called in reverse order of spills due to stack behavior (LIFO).
        Updates the spill offset to track stack shrinkage.

        For region-based spilling, this is only called at region end.

        For A register reloads, ensures we're in the same mode used when spilling,
        since PHA/PLA push/pull different amounts based on m8 vs m16 mode.

        Args:
            spills: List of registers to reload (will be processed in reverse)
        """
        from r65.compiler.codegen.constants import M_FLAG

        for spill in reversed(spills):
            if spill.hw_reg == 'A':
                # Get the mode A was spilled in
                pending = self._region_state.pending_a_spill
                if pending and pending.spill_mode is not None:
                    spill_mode = pending.spill_mode
                    current_mode = self.parent.emitter.get_accu_mode()

                    # Switch to spill mode if different
                    if current_mode != spill_mode:
                        if spill_mode == 16:
                            self._emit_immediate(Opcode.REP_IMMEDIATE, M_FLAG,
                                                 "Switch to m16 for A reload")
                            self.parent.emitter.emit_accu_mode(16)
                        else:
                            self._emit_immediate(Opcode.SEP_IMMEDIATE, M_FLAG,
                                                 "Switch to m8 for A reload")
                            self.parent.emitter.emit_accu_mode(8)

                    self._emit_pull('A', f"Reload A (m{spill_mode})")

                    # Track stack shrinkage based on spill mode
                    if spill_mode == 16:
                        self._region_state.spill_offset -= 2
                    else:
                        self._region_state.spill_offset -= 1

                    # Clear pending A spill
                    self._region_state.pending_a_spill = None
                else:
                    # Fallback: no mode info, assume m8
                    self._emit_pull('A', "Reload A (region end)")
                    self._region_state.spill_offset -= 1
            else:
                # X/Y are always 16-bit (2 bytes)
                self._emit_pull(spill.hw_reg, f"Reload {spill.hw_reg} (region end)")
                self._region_state.spill_offset -= 2

    def get_current_spill_offset(self) -> int:
        """
        Get the current spill offset for adjusting stack-relative accesses.

        Returns:
            Number of bytes currently pushed for spilling
        """
        return self._region_state.spill_offset

    # ========================================================================
    # Argument Setup
    # ========================================================================

    def _emit_argument_setup(self, instr: Call, pre_arg_stack_adj: int = 0) -> int:
        """
        Set up call arguments in correct order.

        Process in specific order to avoid clobbering:
        1. Stack arguments (pushed in REVERSE order - last param first per calling convention)
        2. Variable-bound arguments
        3. B register arguments (these clobber A via XBA)
        4. X and Y register arguments
        5. A register arguments (set up last to avoid being clobbered)

        Args:
            instr: Call instruction
            pre_arg_stack_adj: Stack offset adjustment from operations before arg setup
                (e.g., -2 when PLD was done before args, since S increased by 2)

        Returns:
            Number of bytes pushed on stack (for cleanup)
        """
        from r65.compiler.codegen.type_utils import get_type_size

        stack_bytes_pushed = 0

        # Separate stack arguments from others and reverse them
        # Stack params must be pushed right-to-left (last param first) per calling convention
        # Scratch params are NOT stack args - they use direct store like variable-bound params
        stack_args = [arg for arg in instr.args if arg.mechanism == ArgumentMechanism.STACK]
        other_args = [arg for arg in instr.args if arg.mechanism != ArgumentMechanism.STACK]

        # Push stack arguments in reverse order (last param first)
        for arg in reversed(stack_args):
            arg_loc = self.parent._get_operand_location(arg.value)

            # CRITICAL: Adjust stack-relative source locations for:
            # 1. pre_arg_stack_adj: PLD before args popped 2 bytes (S increased by 2,
            #    so stack items are 2 bytes closer → subtract 2 from offset)
            # 2. stack_bytes_pushed: bytes already pushed by previous args (S decreased,
            #    so stack items are farther → add to offset)
            total_adj = stack_bytes_pushed + pre_arg_stack_adj
            if arg_loc.kind == LocationKind.STACK and total_adj != 0:
                arg_loc = self.parent._offset_location(arg_loc, total_adj)

            self._emit_stack_argument(arg, arg_loc)
            # Track bytes pushed based on argument size - prefer param_type
            arg_size = 1
            if arg.param_type is not None:
                arg_size = get_type_size(arg.param_type)
            elif hasattr(arg.value, 'type_info') and arg.value.type_info:
                arg_size = get_type_size(arg.value.type_info)
            stack_bytes_pushed += arg_size

        # Process other arguments (variable-bound and register) in sorted order
        sorted_other_args = sorted(other_args, key=self._arg_sort_key)
        for arg in sorted_other_args:
            arg_loc = self.parent._get_operand_location(arg.value)

            # CRITICAL: Adjust stack-relative source locations (same logic as above)
            total_adj = stack_bytes_pushed + pre_arg_stack_adj
            if arg_loc.kind == LocationKind.STACK and total_adj != 0:
                arg_loc = self.parent._offset_location(arg_loc, total_adj)

            if arg.mechanism == ArgumentMechanism.REGISTER:
                self._emit_register_argument(arg, arg_loc)

            elif arg.mechanism == ArgumentMechanism.VARIABLE:
                self._emit_variable_argument(arg, arg_loc)

            elif arg.mechanism == ArgumentMechanism.SCRATCH_PARAM:
                self._emit_scratch_param_argument(arg, arg_loc)

        return stack_bytes_pushed

    def _arg_sort_key(self, arg):
        """Sort key for argument processing order."""
        if arg.mechanism == ArgumentMechanism.STACK:
            return 0  # Stack first
        elif arg.mechanism == ArgumentMechanism.SCRATCH_PARAM:
            return 1  # Scratch params second (STA to DP, clobbers A)
        elif arg.mechanism == ArgumentMechanism.VARIABLE:
            return 2  # Variable-bound third
        elif arg.mechanism == ArgumentMechanism.REGISTER:
            target_reg = arg.location.name if hasattr(arg.location, 'name') else str(arg.location)
            if target_reg == 'B':
                return 3  # B fourth (clobbers A)
            elif target_reg in ['X', 'Y']:
                return 4  # X, Y fifth
            elif target_reg == 'A':
                return 5  # A last (to avoid being clobbered)
        return 6

    def _emit_stack_argument(self, arg, arg_loc):
        """Emit stack argument (push onto stack).

        IMPORTANT: This method ensures correct accumulator mode for pushing.
        For 8-bit arguments, we must be in m8 mode so PHA pushes 1 byte.
        For 16-bit arguments loaded byte-by-byte, we use m8 mode.
        For 16-bit arguments already in A, we use m16 mode (single PHA).

        IMPORTANT: When source value is smaller than parameter type, we must
        zero-extend. For example, an 8-bit loop variable passed to a u16
        parameter needs its high byte set to 0, not loaded from garbage memory.
        """
        from r65.compiler.codegen.type_utils import get_type_size
        from r65.compiler.codegen.constants import M_FLAG

        # Determine PARAMETER size (what we need to push)
        param_size = 1
        if arg.param_type is not None:
            param_size = get_type_size(arg.param_type)
        elif hasattr(arg.value, 'type_info') and arg.value.type_info:
            param_size = get_type_size(arg.value.type_info)
        elif isinstance(arg.value, MIRImmediate):
            # Fallback: infer size from immediate value range
            value = arg.value.value
            if value > 0xFFFF or value < -32768:
                param_size = 3  # 24-bit
            elif value > 0xFF or value < -128:
                param_size = 2  # 16-bit
            # else: 8-bit (default)

        # Determine SOURCE size (what we're loading from)
        # This is critical for proper zero-extension
        source_size = param_size  # Default to param size
        if hasattr(arg.value, 'type_info') and arg.value.type_info:
            source_size = get_type_size(arg.value.type_info)
        elif isinstance(arg.value, MIRImmediate):
            # Immediates are already the right size (computed above)
            source_size = param_size

        # Use param_size for how many bytes to push (arg_size variable for compatibility)
        arg_size = param_size

        # Track current mode for proper restoration
        current_mode = self.parent.emitter.get_accu_mode()

        if arg_size == 3:
            # 24-bit value (far pointer): push all 3 bytes (bank, high, low order for stack)
            # IMPORTANT: Must be in m8 mode so each PHA pushes exactly 1 byte
            self._ensure_m8_mode("8-bit A for byte push")

            if arg_loc.kind == LocationKind.HARDWARE and arg_loc.hw_register == 'A':
                raise InstructionSelectionError("Cannot push 24-bit value from A register", source_loc=self.parent._current_source_loc)
            else:
                is_stack = arg_loc.kind == LocationKind.STACK
                self._push_multibyte_value(arg_loc, source_size, 3, is_stack)

        elif arg_size == 2:
            # 16-bit value: push both bytes (high first, then low)
            if arg_loc.kind == LocationKind.HARDWARE and arg_loc.hw_register == 'A':
                # Value is in A - use 16-bit push if in m16, otherwise handle specially
                if current_mode == 16:
                    self._emit_push('A', "Push 16-bit stack arg")
                else:
                    # In m8, need to switch to m16 for single 16-bit push
                    self._emit_immediate(Opcode.REP_IMMEDIATE, M_FLAG, "16-bit A for u16 push")
                    self.parent.emitter.emit_accu_mode(16)
                    self._emit_push('A', "Push 16-bit stack arg")
            elif isinstance(arg.value, MIRImmediate):
                # Immediate 16-bit value: push byte by byte in m8 mode
                self._ensure_m8_mode("8-bit A for byte push")
                value = arg.value.value
                high_byte = (value >> 8) & 0xFF
                low_byte = value & 0xFF
                self._emit_load_immediate('A', high_byte)
                self._emit_push('A', "Push high byte")
                self._emit_load_immediate('A', low_byte)
                self._emit_push('A', "Push low byte")
            else:
                # Memory locations: push byte by byte with zero-extension as needed
                self._ensure_m8_mode("8-bit A for byte push")
                is_stack = arg_loc.kind == LocationKind.STACK
                self._push_multibyte_value(arg_loc, source_size, 2, is_stack)

        else:
            # 8-bit value: single push
            # IMPORTANT: Must be in m8 mode so PHA pushes exactly 1 byte
            self._ensure_m8_mode("8-bit A for u8 push")

            if arg_loc.kind == LocationKind.HARDWARE and arg_loc.hw_register == 'A':
                pass  # Already in A
            elif arg_loc.kind == LocationKind.HARDWARE:
                if arg_loc.hw_register == 'X':
                    self._emit_transfer('X', 'A')
                elif arg_loc.hw_register == 'Y':
                    self._emit_transfer('Y', 'A')
            elif isinstance(arg.value, MIRImmediate):
                self._emit_load_immediate('A', arg.value.value)
            else:
                self.parent._emit_load('LDA', arg_loc)

            self._emit_push('A', "Push stack arg")

    def _emit_register_argument(self, arg, arg_loc):
        """Emit register argument (move to specified register)."""
        from r65.compiler.codegen.type_utils import get_type_size

        target_reg = arg.location.name if hasattr(arg.location, 'name') else str(arg.location)

        if arg_loc.kind == LocationKind.HARDWARE and arg_loc.hw_register == target_reg:
            return  # Already in correct register

        # For A register with 16-bit param type, switch to m16 before loading.
        # X/Y are always 16-bit regardless of M flag, but A depends on it.
        if target_reg == 'A' and arg.param_type is not None:
            if get_type_size(arg.param_type) == 2:
                current_mode = self.emitter.get_accu_mode()
                if current_mode == 8:
                    self._emit_immediate(Opcode.REP_IMMEDIATE, 0x20,
                                         "Switch to m16 for u16 @ A parameter")
                    self.emitter.emit_accu_mode(16)

        if target_reg == 'B':
            self._emit_b_register_argument(arg, arg_loc)
        elif isinstance(arg.value, MIRImmediate):
            self._emit_immediate_to_register(arg.value.value, target_reg)
        elif arg_loc.kind == LocationKind.HARDWARE:
            # Source is a hardware register - emit transfer
            self._emit_hw_to_register(arg_loc.hw_register, target_reg)
        else:
            self._emit_memory_to_register(arg_loc, target_reg)

    def _emit_b_register_argument(self, arg, arg_loc):
        """Emit B register argument (special handling)."""
        if isinstance(arg.value, MIRImmediate):
            self._emit_load_immediate('A', arg.value.value)
            self.parent._store_to_b_from_a()
        elif arg_loc.kind == LocationKind.HARDWARE:
            if arg_loc.hw_register != 'A':
                self.parent._emit_register_transfer(arg_loc.hw_register, 'A')
            self.parent._store_to_b_from_a()
        else:
            self.parent._emit_load('LDA', arg_loc)
            self.parent._store_to_b_from_a()

    def _emit_immediate_to_register(self, value: int, target_reg: str):
        """Load immediate value into target register."""
        self._emit_load_immediate(target_reg, value)

    def _emit_memory_to_register(self, arg_loc, target_reg: str):
        """Load from memory into target register."""
        # Handle stack-relative addressing: LDX/LDY don't support sr,S mode
        if target_reg in ('X', 'Y') and arg_loc.kind == LocationKind.STACK:
            self.parent._emit_load('LDA', arg_loc)
            if target_reg == 'X':
                self._emit_implied(Opcode.TAX, "Transfer to X (no LDX sr,S)")
            else:
                self._emit_implied(Opcode.TAY, "Transfer to Y (no LDY sr,S)")
        else:
            mnemonic = {'A': 'LDA', 'X': 'LDX', 'Y': 'LDY'}.get(target_reg)
            if mnemonic:
                self.parent._emit_load(mnemonic, arg_loc)

    def _emit_hw_to_register(self, src_reg: str, target_reg: str):
        """Transfer from one hardware register to another."""
        if src_reg == target_reg:
            return  # Nothing to do

        # Use appropriate transfer instruction
        if src_reg == 'A' and target_reg == 'X':
            self._emit_implied(Opcode.TAX, f"Transfer A to X")
        elif src_reg == 'A' and target_reg == 'Y':
            self._emit_implied(Opcode.TAY, f"Transfer A to Y")
        elif src_reg == 'X' and target_reg == 'A':
            self._emit_implied(Opcode.TXA, f"Transfer X to A")
        elif src_reg == 'X' and target_reg == 'Y':
            self._emit_implied(Opcode.TXY, f"Transfer X to Y")
        elif src_reg == 'Y' and target_reg == 'A':
            self._emit_implied(Opcode.TYA, f"Transfer Y to A")
        elif src_reg == 'Y' and target_reg == 'X':
            self._emit_implied(Opcode.TYX, f"Transfer Y to X")
        else:
            raise InstructionSelectionError(
                f"Cannot transfer from {src_reg} to {target_reg}",
                source_loc=self.parent._current_source_loc)

    def _emit_variable_argument(self, arg, arg_loc):
        """Emit variable-bound argument (store to memory location)."""
        # Load into A
        if arg_loc.kind == LocationKind.HARDWARE and arg_loc.hw_register == 'A':
            pass  # Already in A
        elif arg_loc.kind == LocationKind.HARDWARE:
            if arg_loc.hw_register == 'X':
                self._emit_transfer('X', 'A')
            elif arg_loc.hw_register == 'Y':
                self._emit_transfer('Y', 'A')
        elif isinstance(arg.value, MIRImmediate):
            self._emit_load_immediate('A', arg.value.value)
        else:
            self.parent._emit_load('LDA', arg_loc)

        # Store to variable location
        var_loc = self.parent._get_operand_location(arg.location)
        self.parent._emit_store('STA', var_loc)

    def _emit_scratch_param_argument(self, arg, arg_loc):
        """
        Emit scratch parameter argument (store to zero-page scratch address).

        Similar to variable-bound, but stores to a specific DP address
        assigned by the scratch parameter analysis pass.
        """
        from r65.compiler.codegen.type_utils import get_type_size
        from r65.compiler.codegen.constants import M_FLAG
        from r65.compiler.codegen.asm_nodes import Address

        scratch_addr = arg.scratch_addr
        param_size = 1
        if arg.param_type is not None:
            param_size = get_type_size(arg.param_type)
        elif hasattr(arg.value, 'type_info') and arg.value.type_info:
            param_size = get_type_size(arg.value.type_info)

        if param_size == 2:
            # 16-bit value: need m16 mode for single STA
            if arg_loc.kind == LocationKind.HARDWARE and arg_loc.hw_register == 'A':
                # Already in A, check mode
                current_mode = self.parent.emitter.get_accu_mode()
                if current_mode != 16:
                    self._emit_immediate(Opcode.REP_IMMEDIATE, M_FLAG, "16-bit A for scratch param")
                    self.parent.emitter.emit_accu_mode(16)
                self.emitter.emit_instr(Opcode.STA_DP, Address(scratch_addr),
                                       f"Scratch param ${scratch_addr:02X}")
                self._emit_immediate(Opcode.SEP_IMMEDIATE, M_FLAG, "Restore 8-bit A")
                self.parent.emitter.emit_accu_mode(8)
            elif isinstance(arg.value, MIRImmediate):
                self._emit_immediate(Opcode.REP_IMMEDIATE, M_FLAG, "16-bit A for scratch param")
                self.parent.emitter.emit_accu_mode(16)
                self._emit_load_immediate('A', arg.value.value)
                self.emitter.emit_instr(Opcode.STA_DP, Address(scratch_addr),
                                       f"Scratch param ${scratch_addr:02X}")
                self._emit_immediate(Opcode.SEP_IMMEDIATE, M_FLAG, "Restore 8-bit A")
                self.parent.emitter.emit_accu_mode(8)
            else:
                self._emit_immediate(Opcode.REP_IMMEDIATE, M_FLAG, "16-bit A for scratch param")
                self.parent.emitter.emit_accu_mode(16)
                self.parent._emit_load('LDA', arg_loc)
                self.emitter.emit_instr(Opcode.STA_DP, Address(scratch_addr),
                                       f"Scratch param ${scratch_addr:02X}")
                self._emit_immediate(Opcode.SEP_IMMEDIATE, M_FLAG, "Restore 8-bit A")
                self.parent.emitter.emit_accu_mode(8)
        else:
            # 8-bit value: standard LDA/STA in m8
            self._ensure_m8_mode("8-bit A for scratch param")

            if arg_loc.kind == LocationKind.HARDWARE and arg_loc.hw_register == 'A':
                pass  # Already in A
            elif arg_loc.kind == LocationKind.HARDWARE:
                if arg_loc.hw_register == 'X':
                    self._emit_transfer('X', 'A')
                elif arg_loc.hw_register == 'Y':
                    self._emit_transfer('Y', 'A')
            elif isinstance(arg.value, MIRImmediate):
                self._emit_load_immediate('A', arg.value.value)
            else:
                self.parent._emit_load('LDA', arg_loc)

            self.emitter.emit_instr(Opcode.STA_DP, Address(scratch_addr),
                                   f"Scratch param ${scratch_addr:02X}")

    # ========================================================================
    # DBR Management
    # ========================================================================

    def _emit_caller_dbr_setup(self, instr: Call) -> bool:
        """
        Handle caller-managed DBR setup if needed.

        Args:
            instr: Call instruction

        Returns:
            True if DBR restore needed after call
        """
        if not (instr.is_far and instr.mode_attr and instr.bank_attr):
            return False

        from r65.compiler.hir.attributes import DataBankMode

        if instr.mode_attr.databank != DataBankMode.CALLER:
            return False

        # Caller manages DBR: save, set, call, restore
        self._emit_push('B', "Save current data bank (caller)")
        self._emit_load_immediate('A', instr.bank_attr.bank_number, "Load callee's bank number")
        self._emit_push('A', "Push bank number")
        self._emit_pull('B', "Set data bank for callee")
        return True

    # ========================================================================
    # Cross-Mode Call Handling
    # ========================================================================

    def _emit_entry_mode_switch(self, instr: Call):
        """
        Switch to callee's entry mode before making the call.

        The callee expects to receive arguments in its entry mode.
        Default caller mode is m8, so we only need to switch if callee expects m16.

        Args:
            instr: Call instruction with callee mode info
        """
        from r65.compiler.typeck.processor_mode import ModeState

        callee_entry = instr.callee_entry_m_mode
        if callee_entry is None:
            return  # No mode info (indirect call or unknown), assume compatible

        # Get current mode from emitter
        current_mode_bits = self.emitter.get_accu_mode()
        current_is_m16 = (current_mode_bits == 16)
        callee_wants_m16 = (callee_entry == ModeState.M16)

        if not current_is_m16 and callee_wants_m16:
            # Caller is m8, callee wants m16 - switch to m16
            self._emit_immediate(Opcode.REP_IMMEDIATE, 0x20, "Switch to m16 for callee")
            self.emitter.emit_accu_mode(16)
        elif current_is_m16 and not callee_wants_m16:
            # Caller is m16, callee wants m8 - switch to m8
            self._emit_immediate(Opcode.SEP_IMMEDIATE, 0x20, "Switch to m8 for callee")
            self.emitter.emit_accu_mode(8)
        # Otherwise modes match, no switch needed

    def _emit_exit_mode_restore(self, instr: Call):
        """
        Restore mode after receiving return value from callee.

        After the call, the caller is in callee's exit mode.
        If callee exited in m16 (u16 return), switch back to m8 (default mode).

        This ensures the caller continues in the expected default mode.

        Args:
            instr: Call instruction with callee mode info
        """
        from r65.compiler.typeck.processor_mode import ModeState

        callee_exit = instr.callee_exit_m_mode
        if callee_exit is None:
            return  # No mode info (indirect call or unknown), assume m8

        if callee_exit == ModeState.M16:
            # Callee returned in m16 mode, switch back to m8
            self._emit_immediate(Opcode.SEP_IMMEDIATE, 0x20, "Restore m8 after u16 return")
            self.emitter.emit_accu_mode(8)
        # If callee exited in m8, we're already in the right mode

    def _update_mode_after_call(self, instr: Call):
        """
        Update emitter's mode tracking to reflect callee's exit mode.

        After the call returns, the CPU is in the callee's exit mode (not entry mode).
        This updates the emitter's tracking without emitting any instructions, so that
        subsequent code (like return value collection) uses the correct mode.

        Args:
            instr: Call instruction with callee mode info
        """
        from r65.compiler.typeck.processor_mode import ModeState

        callee_exit = instr.callee_exit_m_mode
        if callee_exit is None:
            return  # No mode info, assume unchanged

        if callee_exit == ModeState.M16:
            self.emitter.emit_accu_mode(16)
        else:
            self.emitter.emit_accu_mode(8)

    # ========================================================================
    # Call Emission
    # ========================================================================

    def _emit_call_instruction(self, instr: Call, stack_bytes_pushed: int = 0):
        """
        Emit the actual call instruction.

        Handles both direct and indirect calls.

        Args:
            instr: Call instruction
            stack_bytes_pushed: Bytes pushed for stack arguments (shifts fn ptr location)
        """
        if isinstance(instr.function, VirtualRegister):
            # Indirect call through function pointer
            self._emit_indirect_call_trampoline(instr.function, instr.is_far, stack_bytes_pushed)
        elif isinstance(instr.function, str):
            # Direct call
            if instr.is_far:
                self._emit_address(Opcode.JSL, instr.function)
            else:
                self._emit_address(Opcode.JSR, instr.function)
        else:
            raise InstructionSelectionError(f"Unknown function type in Call: {type(instr.function)}", source_loc=self.parent._current_source_loc)

    def _emit_indirect_call_trampoline(self, func_ptr_vreg: VirtualRegister, is_far: bool,
                                       stack_bytes_pushed: int = 0):
        """
        Generate trampoline for indirect function call through function pointer.

        The 65816 RTS/RTL instructions pop an address and add 1 before jumping.
        For a proper call, we need TWO addresses on the stack:
        1. The return address-1 (so the callee's RTS/RTL returns here)
        2. The target address-1 (so our RTS/RTL jumps to the callee)

        Near trampoline (16-bit address):
            ; Push return address (compile-time label, already -1)
            LDA #>(__ret_label - 1)
            PHA
            LDA #<(__ret_label - 1)
            PHA
            ; Push target address from function pointer
            LDA func_ptr+1  ; High byte
            PHA
            LDA func_ptr    ; Low byte
            PHA
            ; Subtract 1 from target (RTS adds 1)
            SEC / SBC chain on $01,S and $02,S
            RTS             ; → callee, callee's RTS → __ret_label
        __ret_label:

        Far trampoline (24-bit address):
            ; Push return address (compile-time, 3 bytes, already -1)
            LDA #:(__ret_label - 1)
            PHA
            LDA #>(__ret_label - 1)
            PHA
            LDA #<(__ret_label - 1)
            PHA
            ; Push target address (3 bytes)
            LDA func_ptr+2, +1, +0 with PHA drift
            ; Subtract 1 from target
            SEC / SBC chain on $01,S..$03,S
            RTL             ; → callee, callee's RTL → __ret_label
        __ret_label:

        Note: For stack-relative locations, each PHA changes the stack pointer,
        so subsequent loads need their offsets adjusted by +1 for each previous PHA.

        Args:
            func_ptr_vreg: VirtualRegister holding the function pointer
            is_far: True for far call (24-bit), False for near call (16-bit)
            stack_bytes_pushed: Bytes pushed for stack arguments before trampoline
        """
        from r65.compiler.codegen.asm_nodes import StackOffset, Immediate

        ret_label = self.parent._get_unique_label()

        # Trampoline must run in m8 mode: each PHA pushes exactly 1 byte,
        # and RTS/RTL pops a fixed 2/3 byte address regardless of m flag.
        self._ensure_m8_mode("8-bit A for trampoline")

        ptr_loc = self.parent._get_operand_location(func_ptr_vreg)
        is_stack = ptr_loc.kind == LocationKind.STACK

        # Adjust ptr_loc for stack arguments pushed before the trampoline
        if is_stack and stack_bytes_pushed > 0:
            ptr_loc = self.parent._offset_location(ptr_loc, stack_bytes_pushed)

        # Track how many bytes we've pushed (for stack-relative drift)
        pha_count = 0

        if is_far:
            # === Far call trampoline (24-bit address) ===

            # Step 1: Push return address - 1 (3 bytes: bank, high, low)
            self._emit_instr(Opcode.LDA_IMMEDIATE, Immediate(f":({ret_label} - 1)"),
                             "Return address bank")
            self._emit_push('A', "Push return bank")
            pha_count += 1
            self._emit_instr(Opcode.LDA_IMMEDIATE, Immediate(f">({ret_label} - 1)"),
                             "Return address high")
            self._emit_push('A', "Push return high")
            pha_count += 1
            self._emit_instr(Opcode.LDA_IMMEDIATE, Immediate(f"<({ret_label} - 1)"),
                             "Return address low")
            self._emit_push('A', "Push return low")
            pha_count += 1

            # Step 2: Push target address (3 bytes from function pointer)
            bank_offset = 2 + (pha_count if is_stack else 0)
            bank_loc = self.parent._offset_location(ptr_loc, bank_offset)
            self.parent._emit_load('LDA', bank_loc, "Load target bank byte")
            self._emit_push('A', "Push target bank")
            pha_count += 1

            high_offset = 1 + (pha_count if is_stack else 0)
            high_loc = self.parent._offset_location(ptr_loc, high_offset)
            self.parent._emit_load('LDA', high_loc, "Load target high byte")
            self._emit_push('A', "Push target high")
            pha_count += 1

            low_offset = 0 + (pha_count if is_stack else 0)
            if low_offset > 0:
                low_loc = self.parent._offset_location(ptr_loc, low_offset)
            else:
                low_loc = ptr_loc
            self.parent._emit_load('LDA', low_loc, "Load target low byte")
            self._emit_push('A', "Push target low")

            # Step 3: Subtract 1 from target address (top 3 bytes on stack)
            self._emit_trampoline_address_adjust(3)

            self._emit_implied(Opcode.RTL, "Indirect far call via trampoline")

            # Step 4: Return label (callee's RTL returns here)
            self.emitter.emit_label(ret_label)
        else:
            # === Near call trampoline (16-bit address) ===

            # Step 1: Push return address - 1 (2 bytes: high, low)
            self._emit_instr(Opcode.LDA_IMMEDIATE, Immediate(f">({ret_label} - 1)"),
                             "Return address high")
            self._emit_push('A', "Push return high")
            pha_count += 1
            self._emit_instr(Opcode.LDA_IMMEDIATE, Immediate(f"<({ret_label} - 1)"),
                             "Return address low")
            self._emit_push('A', "Push return low")
            pha_count += 1

            # Step 2: Push target address (2 bytes from function pointer)
            high_offset = 1 + (pha_count if is_stack else 0)
            high_loc = self.parent._offset_location(ptr_loc, high_offset)
            self.parent._emit_load('LDA', high_loc, "Load target high byte")
            self._emit_push('A', "Push target high")
            pha_count += 1

            low_offset = 0 + (pha_count if is_stack else 0)
            if low_offset > 0:
                low_loc = self.parent._offset_location(ptr_loc, low_offset)
            else:
                low_loc = ptr_loc
            self.parent._emit_load('LDA', low_loc, "Load target low byte")
            self._emit_push('A', "Push target low")

            # Step 3: Subtract 1 from target address (top 2 bytes on stack)
            self._emit_trampoline_address_adjust(2)

            self._emit_implied(Opcode.RTS, "Indirect near call via trampoline")

            # Step 4: Return label (callee's RTS returns here)
            self.emitter.emit_label(ret_label)

    def _emit_trampoline_address_adjust(self, byte_count: int):
        """
        Subtract 1 from address bytes pushed on stack for RTS/RTL trampoline.

        RTS pops 2 bytes and adds 1 before jumping. RTL pops 3 bytes and adds 1.
        So we must push (target_address - 1) for the CPU to jump to the right place.

        Uses SEC/SBC chain with carry propagation to handle byte-boundary wrapping.
        Stack layout after PHAs: [$01,S=low, $02,S=high, $03,S=bank (if far)]

        Args:
            byte_count: Number of address bytes on stack (2 for near, 3 for far)
        """
        from r65.compiler.codegen.asm_nodes import StackOffset

        self._emit_implied(Opcode.SEC, "Subtract 1 from trampoline address")

        for i in range(byte_count):
            stack_pos = i + 1  # $01,S for low, $02,S for high, $03,S for bank
            subtract_val = 1 if i == 0 else 0  # Only subtract 1 from low byte; propagate borrow

            self._emit_instr(Opcode.LDA_STACK, StackOffset(stack_pos))
            self._emit_immediate(Opcode.SBC_IMMEDIATE, subtract_val)
            self._emit_instr(Opcode.STA_STACK, StackOffset(stack_pos))

    # ========================================================================
    # Return Value Collection
    # ========================================================================

    def _get_callee_return_registers(self, instr: Call):
        """
        Get the return register order for a callee based on its return type.

        Args:
            instr: Call instruction with callee info

        Returns:
            List of register names in order
        """
        from r65.compiler.codegen.constants import get_return_registers

        # Try to get callee's return type and mode from the Call instruction
        callee_return_type = getattr(instr, 'callee_return_type', None)
        callee_entry_mode = instr.callee_entry_m_mode if hasattr(instr, 'callee_entry_m_mode') else None

        if callee_return_type is not None:
            return get_return_registers(callee_return_type, callee_entry_mode)
        return ['A', 'X', 'Y']

    def _emit_return_value_collection(self, instr: Call):
        """
        Collect return values from registers.

        Return values come back in A, B, X, Y (in order) depending on
        the callee's return register ordering.
        """
        if not instr.returns:
            return

        return_registers = self._get_callee_return_registers(instr)

        for i, return_vreg in enumerate(instr.returns):
            if i >= len(return_registers):
                raise InstructionSelectionError(f"Too many return values (max {len(return_registers)})", source_loc=self.parent._current_source_loc)

            source_reg = return_registers[i]
            dest_loc = self.parent._get_operand_location(return_vreg)

            if dest_loc.kind == LocationKind.HARDWARE and dest_loc.hw_register == source_reg:
                pass  # Already in correct location
            elif source_reg == 'B':
                # B return: XBA to access B value in A, store, then XBA back
                self.parent._access_b_value_in_a()
                if dest_loc.kind == LocationKind.HARDWARE:
                    if dest_loc.hw_register != 'A':
                        self._emit_return_register_transfer('A', dest_loc.hw_register)
                        self.parent._ensure_xba_state_normal()
                    # If dest is A, the value is already there after XBA - just
                    # need to NOT swap back since we want A to hold the value
                else:
                    self.parent._emit_store('STA', dest_loc)
                    self.parent._ensure_xba_state_normal()
            elif dest_loc.kind == LocationKind.HARDWARE:
                self._emit_return_register_transfer(source_reg, dest_loc.hw_register)
            else:
                self._emit_return_store(source_reg, dest_loc)

    def _emit_return_register_transfer(self, source_reg: str, dest_reg: str):
        """Transfer return value between hardware registers."""
        self._emit_transfer(source_reg, dest_reg)

    def _emit_return_store(self, source_reg: str, dest_loc):
        """Store return value from register to memory."""
        mnemonic = STORE_MNEMONICS.get(source_reg)
        if mnemonic:
            self.parent._emit_store(mnemonic, dest_loc)

    # ========================================================================
    # Built-in Function Calls
    # ========================================================================

    def _emit_builtin_call(self, instr: Call):
        """
        Emit code for built-in function call.

        Built-in categories:
        - Processor control: wai(), stp(), xba(), NOP([count])
        - Mode control: SEP(flags), REP(flags)
        - Block moves: mvn(src_bank, dst_bank), mvp(src_bank, dst_bank)
        - Arithmetic: mul(a, b), div(a, b), mod(a, b) - call runtime library
        - Shifts: shl(a, n), shr(a, n) - call runtime library

        Args:
            instr: Call instruction with builtin_name set
        """
        from r65.compiler.builtins import BuiltinRegistry, BuiltinKind

        builtin = BuiltinRegistry.get_builtin(instr.builtin_name)
        if not builtin:
            raise unknown_value("built-in function", instr.builtin_name, source_loc=self.parent._current_source_loc)

        if builtin.kind == BuiltinKind.PROCESSOR_CONTROL:
            self._emit_processor_control_builtin(instr, builtin)
        elif builtin.kind == BuiltinKind.SOFTWARE_INTERRUPT:
            self._emit_software_interrupt_builtin(instr, builtin)
        elif builtin.kind == BuiltinKind.BLOCK_MOVE:
            self._emit_block_move_builtin(instr, builtin)
        elif builtin.kind in (BuiltinKind.ARITHMETIC, BuiltinKind.SHIFT):
            self._emit_runtime_builtin(instr, builtin)

    def _emit_processor_control_builtin(self, instr: Call, builtin):
        """Emit processor control built-in (wai, stp, xba, NOP)."""
        opcode = BUILTIN_OPCODES.get(builtin.instruction)
        if not opcode:
            raise unknown_value("processor control builtin", builtin.instruction, source_loc=self.parent._current_source_loc)

        if instr.builtin_name == 'NOP':
            count = 1  # Default
            if len(instr.args) == 1:
                arg = instr.args[0]
                if isinstance(arg.value, MIRImmediate):
                    count = arg.value.value
                else:
                    raise InstructionSelectionError("NOP() count must be a constant immediate value", source_loc=self.parent._current_source_loc)

            for _ in range(count):
                self._emit_implied(opcode)
        else:
            self._emit_implied(opcode)

    def _emit_software_interrupt_builtin(self, instr: Call, builtin):
        """Emit software interrupt built-in (cop)."""
        if len(instr.args) != 1:
            raise InstructionSelectionError(
                f"{instr.builtin_name}() expects 1 argument, got {len(instr.args)}", source_loc=self.parent._current_source_loc)

        opcode = BUILTIN_OPCODES.get(builtin.instruction)
        if not opcode:
            raise unknown_value("software interrupt builtin", builtin.instruction, source_loc=self.parent._current_source_loc)

        arg = instr.args[0]

        # COP requires an immediate signature byte
        if isinstance(arg.value, MIRImmediate):
            self._emit_immediate(opcode, arg.value.value)
        else:
            raise InstructionSelectionError(
                f"{instr.builtin_name}() requires a constant signature byte", source_loc=self.parent._current_source_loc)

    def _emit_block_move_builtin(self, instr: Call, builtin):
        """Emit block move built-in (mvn, mvp)."""
        if len(instr.args) != 2:
            raise InstructionSelectionError(
                f"{instr.builtin_name}() expects 2 arguments, got {len(instr.args)}", source_loc=self.parent._current_source_loc)

        src_bank_arg = instr.args[0]
        dst_bank_arg = instr.args[1]

        if not isinstance(src_bank_arg.value, MIRImmediate) or not isinstance(dst_bank_arg.value, MIRImmediate):
            raise InstructionSelectionError(
                f"{instr.builtin_name}() expects immediate bank numbers", source_loc=self.parent._current_source_loc)

        src_bank = src_bank_arg.value.value
        dst_bank = dst_bank_arg.value.value

        opcode = BUILTIN_OPCODES.get(builtin.instruction)
        if not opcode:
            raise unknown_value("block move builtin", builtin.instruction, source_loc=self.parent._current_source_loc)

        self.emitter.emit_instr(opcode, BlockMove(src_bank, dst_bank))

    def _emit_runtime_builtin(self, instr: Call, builtin):
        """Emit runtime library built-in (mul, div, mod, shl, shr)."""
        if len(instr.args) != 2:
            raise InstructionSelectionError(
                f"{instr.builtin_name}() expects 2 arguments, got {len(instr.args)}", source_loc=self.parent._current_source_loc)

        # Load first argument into A
        arg0 = instr.args[0]
        arg0_loc = self.parent._get_operand_location(arg0.value)
        if isinstance(arg0.value, MIRImmediate):
            self._emit_load_immediate('A', arg0.value.value)
        elif arg0_loc.kind == LocationKind.HARDWARE and arg0_loc.hw_register == 'A':
            pass  # Already in A
        elif arg0_loc.kind == LocationKind.HARDWARE and arg0_loc.hw_register == 'X':
            self._emit_implied(Opcode.TXA)  # Transfer X to A
        elif arg0_loc.kind == LocationKind.HARDWARE and arg0_loc.hw_register == 'Y':
            self._emit_implied(Opcode.TYA)  # Transfer Y to A
        else:
            self.parent._emit_load('LDA', arg0_loc)

        # Load second argument into X
        arg1 = instr.args[1]
        arg1_loc = self.parent._get_operand_location(arg1.value)
        if isinstance(arg1.value, MIRImmediate):
            self._emit_load_immediate('X', arg1.value.value)
        elif arg1_loc.kind == LocationKind.HARDWARE and arg1_loc.hw_register == 'X':
            pass  # Already in X
        elif arg1_loc.kind == LocationKind.HARDWARE and arg1_loc.hw_register == 'A':
            self._emit_implied(Opcode.TAX)  # Transfer A to X
        elif arg1_loc.kind == LocationKind.HARDWARE and arg1_loc.hw_register == 'Y':
            # Y to X requires going through A (no direct TYX on 65816)
            # Save A, TYA, TAX, restore A
            self._emit_implied(Opcode.PHA)
            self._emit_implied(Opcode.TYA)
            self._emit_implied(Opcode.TAX)
            self._emit_implied(Opcode.PLA)
        else:
            self.parent._emit_load('LDX', arg1_loc)

        # Call runtime library function
        runtime_func_name = f"__builtin_{instr.builtin_name}"
        self._emit_address(Opcode.JSR, runtime_func_name)

        # Store result if needed
        if instr.returns:
            return_vreg = instr.returns[0]
            dest_loc = self.parent._get_operand_location(return_vreg)

            if dest_loc.kind == LocationKind.HARDWARE and dest_loc.hw_register == 'A':
                pass  # Already in A
            else:
                self.parent._emit_store('STA', dest_loc)

    # ========================================================================
    # D Register Management for Far Pointer Parameters
    # ========================================================================

    def _emit_d_restore_before_call(self):
        """
        Restore D register to its original value before making a call.

        When D = S is set up for far pointer parameters, D must be restored
        before calling other functions that may use zeropage/DP addressing.

        The original D value was saved by PHD in the prologue. We use PLD to
        pop it from the stack and restore it. After the call returns, if we
        need D = S again, we'll push it back with PHD.
        """
        self._emit_instr(Opcode.PLD, comment="Restore D from stack before call")

    def _emit_d_push_only(self):
        """
        Push D back onto the stack after a call.

        Since we used PLD before the call, we must push D back so the
        epilogue's PLD will pop the correct value. This is used when there
        are no more far pointer dereferences after this call.
        """
        self._emit_instr(Opcode.PHD, comment="Save D back to stack for epilogue")

    def _emit_d_equals_s_restore(self):
        """
        Re-establish D = S after a call for continued far pointer access.

        After a call returns, if there are more far pointer dereferences,
        we need to:
        1. Push D back onto the stack (since PLD popped it before the call)
        2. Set D = S for continued far pointer access
        """
        self._emit_instr(Opcode.PHD, comment="Save D back to stack")
        self._emit_instr(Opcode.TSC, comment="Transfer S to A")
        self._emit_instr(Opcode.TCD, comment="Set D = S for far pointer access")

    def _has_far_ptr_derefs_after_call(self, call_instr: Call) -> bool:
        """
        Check if there are far pointer dereferences after this call.

        Uses simple scan approach: checks all remaining instructions in the
        function for LoadIndirect/StoreIndirect with is_far=True.

        Args:
            call_instr: The current Call instruction

        Returns:
            True if far pointer dereferences exist after this call
        """
        from r65.compiler.mir.nodes import LoadIndirect, StoreIndirect

        if not self.parent.current_function:
            return False

        # Find the call instruction's position and scan forward
        found_call = False

        for block in self.parent.current_function.blocks.values():
            for instr in block.instructions:
                if instr is call_instr:
                    found_call = True
                    continue

                if found_call:
                    # Check for far pointer indirect operations
                    if isinstance(instr, (LoadIndirect, StoreIndirect)):
                        if instr.is_far:
                            return True

        return False
