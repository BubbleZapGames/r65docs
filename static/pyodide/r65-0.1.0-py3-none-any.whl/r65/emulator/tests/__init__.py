"""Emulator test suite."""
